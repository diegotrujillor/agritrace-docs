# 🔧 CREAR REPO agritrace-backend EN GITHUB

**Propósito:** Subir el backend que generamos a tu cuenta de GitHub

---

## ✅ PRERREQUISITOS

- Git instalado localmente
- Cuenta GitHub con `agritrace-*` repos existentes
- Terminal abierta
- Archivo `agritrace-backend-clean.tar.gz` descargado

---

## 📋 PASO A PASO

### 1. Descargar y descomprimir

```bash
# Navegar a donde descargaste el archivo
cd ~/Downloads
# o donde hayas descargado agritrace-backend-clean.tar.gz

# Descomprimir
tar -xzf agritrace-backend-clean.tar.gz

# Verificar que se creó la carpeta
ls -la agritrace-backend/
```

**Esperado:**
```
drwxr-xr-x  cmd/
drwxr-xr-x  internal/
drwxr-xr-x  migrations/
drwxr-xr-x  tests/
-rw-r--r--  go.mod
-rw-r--r--  Makefile
-rw-r--r--  .env.example
-rw-r--r--  .gitignore
-rw-r--r--  README.md
```

---

### 2. Navegar a la carpeta

```bash
cd agritrace-backend
pwd  # Debería mostrar la ruta completa
```

---

### 3. Inicializar como repo Git

```bash
git init
git config user.name "Diego Trujillo"
git config user.email "tu@email.com"
```

**Nota:** Si ya configuraste Git globalmente, puedes omitir `git config`

---

### 4. Agregar archivos y hacer commit inicial

```bash
git add .
git commit -m "initial: agritrace backend structure with Go + PostgreSQL

- Fiber framework for REST API
- 30 endpoints documented in OpenAPI spec
- PostgreSQL connection with pgx driver
- Handlers skeleton ready for implementation
- JWT authentication setup
- CORS configured
- Development guidelines integrated"
```

---

### 5. Crear repo en GitHub (Si no existe)

**Opción A: Vía web (recomendado)**

1. Ve a https://github.com/new
2. Nombre: `agritrace-backend`
3. Descripción: "Backend API for AgriTrace MVP - Go + PostgreSQL"
4. **NO inicialices con README** (ya tenemos contenido)
5. **NO agregues .gitignore** (ya tenemos uno)
6. Click "Create repository"

**Opción B: Vía CLI (si tienes GitHub CLI)**

```bash
gh repo create agritrace-backend --public --source=. --remote=origin --push
```

---

### 6. Agregar remote y subir (Si creaste vía web)

```bash
# Agregar URL remota (reemplaza diegotrujillor con tu usuario)
git remote add origin https://github.com/diegotrujillor/agritrace-backend.git

# Cambiar nombre de rama a main si es necesario
git branch -M main

# Subir
git push -u origin main
```

---

### 7. Verificar en GitHub

Abre en navegador:
```
https://github.com/diegotrujillor/agritrace-backend
```

Deberías ver:
- ✅ Carpetas: cmd/, internal/, migrations/, tests/
- ✅ Archivos: go.mod, Makefile, README.md
- ✅ Commit inicial con mensaje

---

## 🚀 PRÓXIMOS PASOS

Una vez el repo esté en GitHub:

### 1. Clonar para desarrollo local
```bash
git clone https://github.com/diegotrujillor/agritrace-backend.git
cd agritrace-backend
```

### 2. Configurar desarrollo
```bash
cp .env.example .env
# Editar .env con tu DATABASE_URL

go mod download
go mod tidy

# Instalar Go 1.21+ si no lo tienes
go version
```

### 3. Crear base de datos
```bash
createdb agritrace_dev

# O en PostgreSQL:
psql
CREATE DATABASE agritrace_dev;
\q
```

### 4. Ejecutar backend
```bash
make dev
```

**Esperado:**
```
✓ Database connected successfully
🚀 Starting AgriTrace API on :3000
```

### 5. Probar con curl
```bash
curl http://localhost:3000/health
# Respuesta: {"status":"ok","timestamp":"..."}
```

---

## 🔗 ESTRUCTURA GITHUB

Cuando todo esté arriba, verás:

```
agritrace-backend/
├── branch: main
├── commits: 1 (initial)
├── files:
│   ├── cmd/
│   ├── internal/
│   ├── migrations/
│   ├── tests/
│   ├── go.mod
│   ├── go.sum (generado)
│   ├── Makefile
│   ├── README.md
│   ├── .gitignore
│   └── .env.example
```

---

## ❌ TROUBLESHOOTING

### Error: "fatal: remote origin already exists"
```bash
git remote remove origin
git remote add origin https://github.com/diegotrujillor/agritrace-backend.git
```

### Error: "remote: Repository not found"
- Verifica que el repo existe en GitHub
- Verifica que la URL es correcta (usuario, nombre repo)
- Verifica permisos (¿es tu cuenta?)

### Error: "fatal: not a git repository"
```bash
# Asegúrate de estar en la carpeta correcta
cd agritrace-backend
git init
```

### Go mod tidy genera errores
```bash
# Instala Go 1.21+
go version

# Verifica que go.mod está en la carpeta raíz
cat go.mod
```

---

## ✅ CHECKLIST

Antes de continuar con Claude Code:

- [ ] `agritrace-backend-clean.tar.gz` descargado
- [ ] Descomprimido a carpeta `agritrace-backend`
- [ ] `git init` ejecutado
- [ ] Repo `agritrace-backend` creado en GitHub
- [ ] `git push` exitoso
- [ ] Puedes ver archivos en GitHub
- [ ] Clonaste localmente: `git clone ...`
- [ ] `.env` configurado con DATABASE_URL
- [ ] `go mod download` ejecutado
- [ ] Base de datos `agritrace_dev` creada
- [ ] `make dev` corre sin errores
- [ ] `curl localhost:3000/health` responde OK

---

## 🎯 AHORA QUÉ

Una vez el backend esté corriendo:

1. **Descarga documentación:**
   - README_FINAL.md
   - FLUTTER_BACKEND_INTEGRATION.md
   - CLAUDE_CODE_PROMPTS.md

2. **Lee el orden:**
   - README_FINAL.md → workflow general
   - FLUTTER_BACKEND_INTEGRATION.md → cómo conectar Flutter
   - CLAUDE_CODE_PROMPTS.md → prompts para implementar

3. **Abre terminal con Claude Code:**
   ```bash
   code .  # Abre VS Code
   # O tu editor favorito con terminal integrada
   ```

4. **Copia + pega primero prompt:**
   - Prompt 3 (Migrations) de CLAUDE_CODE_PROMPTS.md

---

**¡Listo! El backend está en GitHub y listo para desarrollo.** 🚀
