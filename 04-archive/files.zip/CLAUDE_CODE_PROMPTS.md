# 🤖 PROMPTS PARA CLAUDE CODE — AgriTrace Implementation

**Uso:** Copiar + pegar estos prompts en Claude Code para continuar con la implementación

---

## 🔙 BACKEND GO — Implementación de Handlers

### Prompt 1: Implementar Auth Handler

```
Basándote en:
- /docs/openapi-spec.yaml (especificación de endpoints)
- /docs/development-guidelines.md (best practices)
- /docs/database-design.md (schema de BD)

Implementa el handler de autenticación en internal/api/handlers/handlers.go:

1. Register: Validar email único, hashear password con bcrypt, guardar en BD
2. Login: Validar credenciales, generar JWT (acceso 15min, refresh 7 días)
3. RefreshToken: Validar refresh token, generar nuevo access token
4. Logout: Invalidar token (o simplemente informar al cliente)

Sigue el patrón:
- Input validation con Zod/Joi equivalent
- Error handling con códigos HTTP apropiados
- Logging de acciones críticas
- JWT signing con HS256

Crea también en internal/utils/jwt_handler.go:
- GenerateToken(userID, role, expiryMinutes) -> string
- ValidateToken(token) -> (*Claims, error)
- Claims struct con sub (subject/userID), role, exp, iat

Referencia:
- OpenAPI: /v1/auth/register, /v1/auth/login, /v1/auth/refresh
- DB: users table con password_hash (bcrypt)
```

### Prompt 2: Implementar Farm Handler CRUD

```
Basándote en:
- /docs/openapi-spec.yaml (endpoints /farms)
- /docs/development-guidelines.md (best practices)
- /docs/database-design.md (Farm model, índices)

Implementa todos los handlers de Farm en internal/api/handlers/handlers.go:

1. CreateFarm
   - Validar inputs (name, latitude, longitude, etc)
   - Guardar con producer_id del user autenticado
   - Retornar 201 con Farm object

2. GetFarm
   - Obtener por ID
   - Validar que usuario es dueño o es admin
   - Retornar 200 o 404

3. UpdateFarm
   - Validar inputs parciales (algunos campos opcionales)
   - Solo dueño puede actualizar
   - Retornar 200

4. DeleteFarm (soft delete)
   - Marcar deleted_at = NOW()
   - Solo dueño puede eliminar
   - Retornar 204

5. ListProducerFarms
   - Listar todas las fincas de un productor
   - Paginación (limit, offset)
   - Retornar array + pagination metadata

Crea también en internal/services/farm_service.go:
- FarmService struct con DB
- Métodos: Create, GetByID, Update, Delete, ListByProducer
- Transacciones si es necesario

Middleware: Autenticación requerida en todas excepto si hay public endpoints

Referencia:
- OpenAPI: /v1/farms
- DB queries: preparadas statements (SQL injection prevention)
- Logs: action, userID, farmID, changes
```

### Prompt 3: Implementar Database Migrations

```
Basándote en:
- /docs/database-design.md (todas las tablas)

Crea archivos SQL en migrations/:

1. 001_create_users.sql
   - CREATE TABLE users (...)
   - Índices: email UNIQUE, role, is_active
   
2. 002_create_producers.sql
   - CREATE TABLE producers (...)
   - FK: user_id REFERENCES users
   
3. 003_create_farms.sql
   - CREATE TABLE farms (...)
   - FK: producer_id REFERENCES producers
   - Índices: producer_id, location (lat/lng)
   
4. 004_create_plots.sql
   - CREATE TABLE plots (...)
   - FK: farm_id REFERENCES farms
   - Índices: farm_id, status

5. 005_create_activities.sql
   - CREATE TABLE activities (...)
   - FK: plot_id REFERENCES plots
   - Índices: plot_id, activity_date
   
6. 006_create_qr_codes.sql
   - CREATE TABLE qr_codes (...)
   - FK: plot_id REFERENCES plots UNIQUE
   - Índices: code UNIQUE
   
7. 007_create_certificates.sql
   - CREATE TABLE certificates (...)
   - FK: plot_id, verified_by (admin)
   
8. 008_create_audit_logs.sql
   - CREATE TABLE audit_logs (...)
   - Para trazabilidad del sistema

Crea también internal/db/migrations.go:
- RunMigrations(db *pgxpool.Pool) error
- Lee archivos SQL de migrations/
- Ejecuta en orden

Llamar en cmd/main.go antes de iniciar servidor:
  if err := db.RunMigrations(dbConn); err != nil { ... }
```

---

## 📱 FRONTEND FLUTTER — Integración con Backend

### Prompt 4: Crear API Client y Auth Service

```
En agritrace-prototype/lib/:

Crea services/api_client.dart:
- ApiClient class
- Configurar base URL (localhost:3000)
- Headers por defecto (Content-Type)
- Métodos: get, post, put, delete (generic <T>)
- Manejo de errores: status code → ApiException
- Token management: leer de secure storage, agregar a headers
- Auto-refresh de token en 401

Crea services/auth_service.dart:
- AuthService class
- register(email, password, fullName, phone, role) -> User
- login(email, password) -> LoginResponse (con tokens)
- logout() -> void
- refreshToken() -> bool
- guardadar tokens en FlutterSecureStorage
- Manejo de errores con ApiException

Crea utils/error_handler.dart:
- ApiErrorType enum
- ApiException class
- mapear HTTP status codes a mensajes de usuario

Crea models/:
- user.dart: User struct
- auth.dart: LoginResponse, RegisterInput
- api_response.dart: ApiResponse<T> (wrapper)

Actualizar pubspec.yaml:
  http: ^1.1.0
  flutter_secure_storage: ^9.0.0
  provider: ^6.0.0 (para state management)

Referencia:
- openapi-spec.yaml: /v1/auth/* endpoints
- FLUTTER_BACKEND_INTEGRATION.md: Auth flow
```

### Prompt 5: Crear Farm Service y Conectar UI

```
En agritrace-prototype/lib/:

Crea services/farm_service.dart:
- FarmService class
- getFarms(producerId) -> Future<List<Farm>>
- getFarm(farmId) -> Future<Farm>
- createFarm(FarmInput) -> Future<Farm>
- updateFarm(farmId, FarmInput) -> Future<Farm>
- deleteFarm(farmId) -> Future<void>

Crea models/farm.dart:
- Farm struct (id, producerId, name, municipality, latitude, longitude, mainCrop, area, createdAt, updatedAt)
- FarmInput struct (para crear/actualizar)
- JSON serialization (fromJson, toJson)

Crea providers/farm_provider.dart:
- FarmProvider (ChangeNotifier)
- farms: List<Farm>
- isLoading: bool
- error: String?
- getFarmsForProducer()
- createFarm()
- updateFarm()
- deleteFarm()
- notifyListeners cuando cambios

Conecta en screens/farms_screen.dart:
- En initState(): Provider.of<FarmProvider>(context).getFarmsForProducer()
- En build(): Consumer<FarmProvider>(builder: ...)
- FarmCard para cada farm
- FloatingActionButton: "Agregar finca" → add_farm_screen
- Manejo de errors: mostrar SnackBar

Conecta en screens/add_farm_screen.dart:
- Formulario con TextFields (name, municipality, crop, etc)
- Botón Crear: validate() → farm_service.createFarm()
- En éxito: pop con resultado
- En error: mostrar AlertDialog

Referencia:
- openapi-spec.yaml: /v1/farms
- FLUTTER_BACKEND_INTEGRATION.md: Ejemplo createFarm
- development-guidelines.md: Best practices Flutter
```

### Prompt 6: Offline Sync con WatermelonDB

```
Implementar sincronización offline en agritrace-prototype/lib/:

Crea storage/watermelon_db.dart:
- Database setup con tablas: farms, plots, activities
- Schemas con campos: id, producer_id, status (synced/pending), offline_id, synced_at
- RecordsDatabase abstraction

Crea providers/sync_provider.dart:
- SyncProvider (ChangeNotifier)
- isOnline: bool
- pendingChanges: int
- lastSyncTime: DateTime?
- startConnectivityListener()
- syncPendingChanges()
- Usar Connectivity package para detectar online/offline

Crea services/sync_service.dart:
- SyncService class
- uploadPendingFarms()
- uploadPendingPlots()
- uploadPendingActivities()
- Para cada pendiente: POST a API con offline_id
- Si éxito: actualizar BD local (status=synced, id=server_id)
- Si error: marcar status=failed, permitir reintentos

Conecta en main.dart:
- En main(): Provider setup + startConnectivityListener()
- En screens: mostrar "Sincronizando..." cuando pendingChanges > 0

Actualizar pubspec.yaml:
  connectivity_plus: ^5.0.0
  sqflite: ^2.3.0
  uuid: ^4.0.0

Referencia:
- FLUTTER_BACKEND_INTEGRATION.md: Offline sync section
- WatermelonDB: https://watermelondb.org/
```

---

## 🔗 INTEGRACIÓN END-TO-END

### Prompt 7: Setup Completo - Backend + Frontend

```
Resumen de setup:

BACKEND (Go):
1. go mod download
2. cp .env.example .env
3. Editar .env con DATABASE_URL
4. make dev → debería compilar + correr
5. curl http://localhost:3000/health → {"status":"ok"}

BASE DE DATOS:
1. createdb agritrace_dev
2. Backend corre migraciones automáticamente (en cmd/main.go)
3. Verificar: psql agritrace_dev \dt → lista de tablas

FRONTEND (Flutter):
1. cd agritrace-prototype
2. flutter pub get (o: flutter pub upgrade)
3. flutter run -d <device>
   - Si es web: flutter run -d web
   - Si es android: flutter run -d <emulator/device>
4. Verificar que app inicia en splash_screen

CONEXIÓN:
1. En Flutter, api_client.dart apunta a http://localhost:3000
   - Si es emulator Android: cambiar a http://10.0.2.2:3000
   - Si es web: http://localhost:3000 funciona
2. Navegar a login_screen
3. Probar registro + login contra API real
4. Verificar en Go que logs muestran requests (JWT tokens válidos)

DEBUGGING:
- Backend: make dev muestra logs en console
- Frontend: flutter run con -v para verbose
- Network: Chrome DevTools (si es web) o Charles Proxy
- BD: psql agritrace_dev \d para esquema

Referencia:
- QUICK_START_BACKEND.md
- FLUTTER_BACKEND_INTEGRATION.md
```

---

## 📋 ORDEN RECOMENDADO DE IMPLEMENTACIÓN

### Semana 1: Backend Foundation
```
Día 1-2:
  [Prompt 3] Migrations
  [Prompt 1] Auth Handler
  
Día 3-4:
  [Prompt 2] Farm Handler CRUD
  
Día 5:
  [Prompt 7] Setup e integration testing
  curl http://localhost:3000/health
  curl -X POST http://localhost:3000/v1/auth/login -d '{"email":"...","password":"..."}'
```

### Semana 2: Frontend Integration
```
Día 1:
  [Prompt 4] API Client + Auth Service
  
Día 2-3:
  [Prompt 5] Farm Service + UI integration
  
Día 4-5:
  [Prompt 6] Offline Sync
```

### Semana 3-4: Complete Features
```
- Plot CRUD handlers (backend)
- Activity CRUD handlers (backend)
- QR generation service
- Certificate management
- Traceability public API
- Tests para todos los endpoints
```

---

## 🔧 TROUBLESHOOTING PROMPTS

### Si hay error en compilación Go:
```
Revisa:
1. go version >= 1.21
2. go mod tidy (resolver dependencias)
3. Imports correctos en main.go
4. Sintaxis de Go (colchetes, puntos y comas)

Si persiste:
  go build ./cmd -v (verbose)
```

### Si Flutter no conecta con backend:
```
Checklist:
1. Backend corre: curl http://localhost:3000/health
2. CORS habilitado en Fiber (está en main.go)
3. API URL correcta en api_client.dart (localhost vs 10.0.2.2)
4. Firewall permite conexión

Si es Android emulator: usar 10.0.2.2 en lugar de localhost
```

### Si JWT token expira constantemente:
```
Revisar:
1. JWTSecret en .env (debe ser 32+ chars)
2. JWT expiry en config (15 minutos para access token)
3. Refresh token logic en api_client.dart
4. Clock sync en máquina (importante para JWT!)
```

---

## 📚 DOCUMENTACIÓN A CONSULTAR

Antes de cada prompt, lee:
1. **development-guidelines.md** - Cómo escribir código en este proyecto
2. **openapi-spec.yaml** - Qué endpoints existen + qué esperan
3. **database-design.md** - Schema de BD + relaciones
4. **FLUTTER_BACKEND_INTEGRATION.md** - Cómo Flutter llama API

---

## 💡 TIPS

1. **Scaffolding:** Usa las siguientes carpetas ya creadas:
   - Backend: cmd/, internal/config, internal/db, internal/models, internal/api
   - Flutter: lib/services, lib/models, lib/screens, lib/widgets

2. **Testing:** Después de cada handler:
   ```bash
   curl -X POST http://localhost:3000/v1/endpoint \
     -H "Authorization: Bearer <token>" \
     -H "Content-Type: application/json" \
     -d '{...}'
   ```

3. **Logging:** Usa logger en utils/ para debugging

4. **Errors:** Siempre retorna estructura coherente:
   ```json
   {"error": "descriptivo", "code": "VALIDATION_ERROR"}
   ```

5. **Commits:** Después de cada handler:
   ```bash
   git add .
   git commit -m "feat: implement {handler} endpoints"
   git push
   ```

---

**Listo para empezar. Copia + pega cualquiera de estos prompts en Claude Code y sigue adelante.** 🚀
