# 🔗 INTEGRACIÓN FLUTTER + GO BACKEND — AgriTrace

**Propósito:** Mantener el prototipo Flutter + conectarlo con el backend Go

---

## 📐 ARQUITECTURA

```
┌─────────────────────────────────────────────────┐
│     Flutter App (agritrace-prototype)           │
│  • Pantallas (9 screens)                        │
│  • Navegación                                   │
│  • UI/UX (Design Tokens implementados)          │
│  • WatermelonDB (BD local offline)              │
└─────────────────┬───────────────────────────────┘
                  │
        HTTP/REST + JWT Token
        Content-Type: application/json
                  │
                  ▼
┌─────────────────────────────────────────────────┐
│   Go Backend (agritrace-backend)                │
│  • http://localhost:3000/v1/*                   │
│  • Endpoints REST (30 documentados)             │
│  • JWT Validation                               │
│  • Business Logic                               │
└─────────────────┬───────────────────────────────┘
                  │
              PostgreSQL driver (pgx)
                  │
                  ▼
┌─────────────────────────────────────────────────┐
│   PostgreSQL (localhost:5432)                   │
│  • users, farms, plots, activities, etc         │
│  • Transacciones ACID                           │
│  • Backups automáticos                          │
└─────────────────────────────────────────────────┘
```

---

## 📦 ESTRUCTURA FLUTTER (Recomendada)

Mantener lo existente + agregar:

```
agritrace-prototype/
├── lib/
│   ├── main.dart                           # (existente)
│   │
│   ├── services/                           # NUEVO: API client
│   │   ├── api_client.dart                 # HTTP client config
│   │   ├── auth_service.dart               # Login, register, token refresh
│   │   ├── farm_service.dart               # GET/POST/PUT farms
│   │   ├── plot_service.dart               # GET/POST/PUT plots
│   │   ├── activity_service.dart           # GET/POST activities
│   │   ├── qr_service.dart                 # Generate + verify QR
│   │   └── traceability_service.dart       # Public traceability API
│   │
│   ├── models/                             # NUEVO: Data classes
│   │   ├── user.dart
│   │   ├── farm.dart
│   │   ├── plot.dart
│   │   ├── activity.dart
│   │   ├── qr_code.dart
│   │   ├── certificate.dart
│   │   └── api_response.dart               # Wrapper para respuestas
│   │
│   ├── providers/                          # NUEVO: State management
│   │   ├── auth_provider.dart              # Manejo de tokens + user
│   │   ├── farm_provider.dart              # Farms CRUD + sync
│   │   ├── plot_provider.dart              # Plots CRUD + sync
│   │   ├── activity_provider.dart          # Activities sync
│   │   └── connectivity_provider.dart      # Offline/Online status
│   │
│   ├── screens/                            # (mantener existentes)
│   │   ├── splash_screen.dart
│   │   ├── login_screen.dart               # → Llamar auth_service.login()
│   │   ├── register_screen.dart            # → Llamar auth_service.register()
│   │   ├── home_screen.dart
│   │   ├── farms_screen.dart               # → Llamar farm_service.getFarms()
│   │   ├── farm_detail_screen.dart
│   │   ├── add_farm_screen.dart            # → POST farm_service.createFarm()
│   │   ├── activity_screen.dart
│   │   ├── qr_screen.dart                  # → Llamar qr_service
│   │   └── traceability_screen.dart        # → Público (sin auth)
│   │
│   ├── widgets/                            # (mantener existentes)
│   │   └── ...
│   │
│   ├── config/                             # NUEVO: Configuración
│   │   ├── app_config.dart                 # URLs de API
│   │   └── constants.dart                  # Rutas, timeouts, etc
│   │
│   ├── utils/                              # NUEVO: Utilidades
│   │   ├── jwt_handler.dart                # Decode JWT, check expiry
│   │   ├── logger.dart                     # Logging
│   │   └── error_handler.dart              # Parse errores de API
│   │
│   └── storage/                            # NUEVO: Persistencia offline
│       ├── local_storage.dart              # SharedPreferences
│       └── watermelon_db.dart              # WatermelonDB para sync
│
├── pubspec.yaml                            # Actualizar con nuevas deps
├── lib/config/                             # .env equivalent
│   └── environment.dart
│
└── documentation/
    ├── API_INTEGRATION.md                  # Este archivo
    ├── OFFLINE_SYNC.md                     # WatermelonDB + sync
    ├── AUTH_FLOW.md                        # JWT token flow
    └── ERROR_HANDLING.md                   # Error codes de API
```

---

## 🔌 DEPENDENCIAS FLUTTER A AGREGAR

### pubspec.yaml

```yaml
dependencies:
  flutter:
    sdk: flutter
  
  # Networking
  http: ^1.1.0              # HTTP client
  dio: ^5.3.0               # Alternative: mejor manejo de errores
  
  # State Management
  provider: ^6.0.0          # Provider pattern
  # O: riverpod: ^2.4.0     # Alternative: más type-safe
  
  # Offline Storage
  shared_preferences: ^2.2.0       # Guardar tokens
  sqflite: ^2.3.0                  # BD local simple
  watermelon_db: ^0.4.0            # O usar SQLite con sync automático
  
  # JSON Serialization
  json_serializable: ^6.7.0
  json_annotation: ^4.8.1
  
  # Authentication
  flutter_secure_storage: ^9.0.0   # Guardar tokens seguro
  
  # Utilities
  uuid: ^4.0.0              # Generar IDs únicos offline
  intl: ^0.19.0             # Localización, fechas
  connectivity_plus: ^5.0.0 # Detectar online/offline
  
  # QR (si lo necesitas)
  mobile_scanner: ^3.4.0    # Escanear QR
  qr_flutter: ^4.1.0        # Generar QR

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^2.0.0
  build_runner: ^2.4.0
  json_serializable: ^6.7.0
```

---

## 🔐 AUTH FLOW

### 1. Login (con JWT token)

**Flutter → Go:**
```dart
// login_service.dart
Future<LoginResponse> login(String email, String password) async {
  final response = await http.post(
    Uri.parse('http://localhost:3000/v1/auth/login'),
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode({
      'email': email,
      'password': password,
    }),
  );

  if (response.statusCode == 200) {
    final data = jsonDecode(response.body);
    
    // Guardar tokens en secure storage
    final storage = FlutterSecureStorage();
    await storage.write(key: 'accessToken', value: data['accessToken']);
    await storage.write(key: 'refreshToken', value: data['refreshToken']);
    
    return LoginResponse.fromJson(data);
  } else {
    throw Exception('Login failed: ${response.body}');
  }
}
```

**Go responde:**
```json
{
  "accessToken": "eyJhbGc...",
  "refreshToken": "eyJhbGc...",
  "user": {
    "id": "uuid",
    "email": "juan@example.com",
    "fullName": "Juan Gómez",
    "role": "producer"
  }
}
```

### 2. Usar token en requests

```dart
// api_client.dart
Future<T> get<T>(String path) async {
  final storage = FlutterSecureStorage();
  final token = await storage.read(key: 'accessToken');
  
  final response = await http.get(
    Uri.parse('http://localhost:3000/v1$path'),
    headers: {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    },
  );
  
  if (response.statusCode == 401) {
    // Token expirado, renovar
    await refreshToken();
    return get<T>(path); // Reintentar
  }
  
  return _parseResponse<T>(response);
}

Future<void> refreshToken() async {
  final storage = FlutterSecureStorage();
  final refreshToken = await storage.read(key: 'refreshToken');
  
  final response = await http.post(
    Uri.parse('http://localhost:3000/v1/auth/refresh'),
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode({'refreshToken': refreshToken}),
  );
  
  if (response.statusCode == 200) {
    final data = jsonDecode(response.body);
    await storage.write(key: 'accessToken', value: data['accessToken']);
  } else {
    throw Exception('Token refresh failed');
  }
}
```

### 3. Logout

```dart
Future<void> logout() async {
  final storage = FlutterSecureStorage();
  await storage.delete(key: 'accessToken');
  await storage.delete(key: 'refreshToken');
  // Navegar a login screen
}
```

---

## 📡 LLAMADAS A ENDPOINTS

### Obtener fincas del productor

**Flutter:**
```dart
// farm_service.dart
Future<List<Farm>> getFarms(String producerId) async {
  final response = await apiClient.get(
    '/farms/producer/$producerId'
  );
  
  final List<dynamic> data = response['data'];
  return data.map((json) => Farm.fromJson(json)).toList();
}
```

**Go endpoint:**
```
GET /v1/farms/producer/{producerId}
Authorization: Bearer <token>

Respuesta:
{
  "data": [
    {
      "id": "uuid",
      "producerId": "uuid",
      "name": "Mi Finca",
      "municipality": "Cali",
      "latitude": 3.4372,
      "longitude": -76.5196,
      "mainCrop": "Piña",
      "totalArea": 10.5,
      "createdAt": "2024-04-30T10:30:00Z"
    }
  ]
}
```

---

### Crear una nueva finca

**Flutter:**
```dart
// farm_service.dart
Future<Farm> createFarm(FarmInput input) async {
  final response = await apiClient.post(
    '/farms',
    body: input.toJson(),
  );
  
  return Farm.fromJson(response['data']);
}

// En add_farm_screen.dart
onPressed: () async {
  final farm = FarmInput(
    name: nameController.text,
    municipality: municipalityController.text,
    latitude: double.parse(latitudeController.text),
    longitude: double.parse(longitudeController.text),
    mainCrop: cropController.text,
  );
  
  try {
    final created = await farmService.createFarm(farm);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Finca "${created.name}" creada'))
    );
    Navigator.pop(context, created);
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Error: $e'))
    );
  }
}
```

**Go endpoint:**
```
POST /v1/farms
Authorization: Bearer <token>
Content-Type: application/json

Body:
{
  "name": "Mi Finca",
  "municipality": "Cali",
  "latitude": 3.4372,
  "longitude": -76.5196,
  "mainCrop": "Piña"
}

Respuesta 201:
{
  "data": {
    "id": "uuid-generado",
    "producerId": "uuid-del-usuario",
    "name": "Mi Finca",
    "...": "..."
  }
}
```

---

## 🔄 OFFLINE SYNC (WatermelonDB)

### Estrategia

```
App Local (WatermelonDB)
    ↓ (queued changes)
    ↓ (cuando hay conexión)
API Backend
    ↓ (procesa cambios)
PostgreSQL
```

### Implementación

```dart
// storage/watermelon_db.dart
import 'package:watermelon_db/watermelon_db.dart';

class AgriTraceDatabase {
  static final database = Database(
    name: 'agritrace_db',
    tables: [
      farmsTable,
      plotsTable,
      activitiesTable,
    ],
  );

  static Table farmsTable = Table(
    name: 'farms',
    columns: [
      Column.text('id'),
      Column.text('producer_id'),
      Column.text('name'),
      Column.text('municipality'),
      Column.real('latitude'),
      Column.real('longitude'),
      Column.text('status'), // synced, pending, failed
      Column.text('offline_id'), // ID local antes de sync
      Column.datetime('synced_at'),
    ],
  );
}

// Crear un registro localmente
Future<void> createFarmOffline(FarmInput input) async {
  final db = AgriTraceDatabase.database;
  
  final id = uuid.v4(); // ID local
  await db.batch((batch) {
    batch.insert(farmsTable.name, {
      'id': id,
      'producer_id': currentUserId,
      'name': input.name,
      'municipality': input.municipality,
      'latitude': input.latitude,
      'longitude': input.longitude,
      'status': 'pending', // Marca como no sincronizado
      'offline_id': id,
    });
  });
}

// Sincronizar cuando hay conexión
Future<void> syncFarms() async {
  final connectivity = await Connectivity().checkConnectivity();
  if (connectivity == ConnectivityResult.none) return;
  
  final db = AgriTraceDatabase.database;
  
  // Obtener registros pendientes
  final pendingFarms = await db.query(
    "SELECT * FROM farms WHERE status = 'pending'"
  );
  
  for (var farm in pendingFarms) {
    try {
      final response = await farmService.createFarm(
        FarmInput.fromJson(farm),
      );
      
      // Actualizar con ID del servidor y marcar como sincronizado
      await db.update(farmsTable.name, farm['id'], {
        'id': response.id,
        'status': 'synced',
        'synced_at': DateTime.now(),
      });
    } catch (e) {
      // Marcar como fallido, permitir reintentos
      await db.update(farmsTable.name, farm['id'], {
        'status': 'failed',
      });
    }
  }
}

// En main.dart, iniciar sync periódicamente
void _startSyncListener() {
  Connectivity().onConnectivityChanged.listen((result) {
    if (result != ConnectivityResult.none) {
      syncFarms(); // Sincronizar cuando vuelve conexión
    }
  });
}
```

---

## ⚠️ MANEJO DE ERRORES

### Códigos de error de API

```dart
// utils/error_handler.dart
enum ApiErrorType {
  unauthorized,      // 401 - Token inválido
  forbidden,        // 403 - No tienes permiso
  notFound,         // 404 - Recurso no existe
  validation,       // 400 - Datos inválidos
  conflict,         // 409 - Recurso ya existe
  rateLimit,        // 429 - Demasiadas requests
  serverError,      // 500+ - Error del servidor
  networkError,     // Sin conexión
  unknown,          // Otro
}

class ApiException implements Exception {
  final ApiErrorType type;
  final String message;
  final int? statusCode;
  final dynamic originalError;

  ApiException({
    required this.type,
    required this.message,
    this.statusCode,
    this.originalError,
  });

  @override
  String toString() => message;

  factory ApiException.fromResponse(http.Response response) {
    final body = jsonDecode(response.body) ?? {};
    final message = body['message'] ?? 'Error desconocido';

    switch (response.statusCode) {
      case 400:
        return ApiException(
          type: ApiErrorType.validation,
          message: message,
          statusCode: 400,
        );
      case 401:
        return ApiException(
          type: ApiErrorType.unauthorized,
          message: 'Tu sesión expiró. Inicia sesión nuevamente.',
          statusCode: 401,
        );
      case 403:
        return ApiException(
          type: ApiErrorType.forbidden,
          message: 'No tienes permiso para esta acción.',
          statusCode: 403,
        );
      case 404:
        return ApiException(
          type: ApiErrorType.notFound,
          message: 'El recurso no fue encontrado.',
          statusCode: 404,
        );
      default:
        return ApiException(
          type: ApiErrorType.serverError,
          message: 'Error del servidor: ${response.statusCode}',
          statusCode: response.statusCode,
        );
    }
  }
}

// En screens, capturar errores
try {
  await farmService.createFarm(input);
} on ApiException catch (e) {
  switch (e.type) {
    case ApiErrorType.validation:
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Datos inválidos'),
          content: Text(e.message),
        ),
      );
      break;
    case ApiErrorType.unauthorized:
      // Redirigir a login
      Navigator.pushReplacementNamed(context, '/login');
      break;
    default:
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.message}'))
      );
  }
}
```

---

## 🧪 TESTING

### Test de API client

```dart
// test/services/farm_service_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';

void main() {
  group('FarmService', () {
    late FarmService farmService;
    late MockHttpClient mockHttpClient;

    setUp(() {
      mockHttpClient = MockHttpClient();
      farmService = FarmService(client: mockHttpClient);
    });

    test('getFarms retorna lista de fincas', () async {
      when(mockHttpClient.get(
        any,
        headers: anyNamed('headers'),
      )).thenAnswer(
        (_) async => http.Response(
          jsonEncode({
            'data': [
              {
                'id': '123',
                'name': 'Mi Finca',
                'municipality': 'Cali',
                'latitude': 3.4,
                'longitude': -76.5,
              }
            ]
          }),
          200,
        ),
      );

      final farms = await farmService.getFarms('producer-123');

      expect(farms.length, 1);
      expect(farms[0].name, 'Mi Finca');
    });

    test('createFarm lanza error si status != 201', () async {
      when(mockHttpClient.post(
        any,
        headers: anyNamed('headers'),
        body: anyNamed('body'),
      )).thenAnswer(
        (_) async => http.Response(
          jsonEncode({'message': 'Validation error'}),
          400,
        ),
      );

      expect(
        () => farmService.createFarm(FarmInput(...)),
        throwsA(isA<ApiException>()),
      );
    });
  });
}
```

---

## 🔗 ENDPOINTS A INTEGRAR

### Priority 1 (MVP Core)
```
✅ POST /auth/register       → register_screen.dart
✅ POST /auth/login          → login_screen.dart
✅ POST /auth/refresh        → api_client.dart (automático)
✅ GET  /farms/producer/:id  → farms_screen.dart
✅ POST /farms               → add_farm_screen.dart
✅ GET  /plots/:id           → plot_detail_screen.dart
✅ POST /plots               → create_plot_screen.dart
✅ POST /activities          → activity_screen.dart
✅ POST /qr/generate         → qr_screen.dart
✅ GET  /traceability/:code  → traceability_screen.dart (público)
```

### Priority 2 (Fase 2)
```
⏳ GET  /certificates/plot/:id
⏳ POST /certificates
⏳ PUT  /farms/:id
⏳ PUT  /plots/:id
⏳ GET  /activities/plot/:id
```

---

## 🚀 CHECKLIST INTEGRACIÓN

### Backend (Go)
- [ ] Servidor corriendo en localhost:3000
- [ ] Base de datos conectada
- [ ] Migraciones ejecutadas (CREATE tables)
- [ ] CORS habilitado para port 3000 (Flutter web) y 5173 (React)
- [ ] Auth endpoints funcionando (login, register, refresh)
- [ ] Health check en /health

### Frontend (Flutter)
- [ ] agregar http/dio en pubspec.yaml
- [ ] agregar flutter_secure_storage
- [ ] Crear api_client.dart
- [ ] Crear auth_service.dart
- [ ] Crear farm_service.dart, plot_service.dart, etc
- [ ] Agregar models (Farm, Plot, Activity, etc)
- [ ] Conectar login_screen a auth_service
- [ ] Conectar farms_screen a farm_service
- [ ] Manejar errores (401, 400, 500)
- [ ] Offline sync con WatermelonDB (Fase 2)

---

## 📚 REFERENCIAS

- **Http client Dart:** https://pub.dev/packages/http
- **Provider pattern:** https://pub.dev/packages/provider
- **Secure Storage:** https://pub.dev/packages/flutter_secure_storage
- **WatermelonDB:** https://watermelondb.org/
- **Connectivity:** https://pub.dev/packages/connectivity_plus

---

**Próximo paso:** Implementar auth_service.dart + login_screen integration
